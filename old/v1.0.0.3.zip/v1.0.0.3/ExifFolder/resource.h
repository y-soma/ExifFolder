//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ExifFolder.rc
//
#define IDD_MAIN_DIALOG                 101
#define IDI_ICON1                       102
#define IDD_PROGRESS_DIALOG             105
#define IDC_TAGLIST_COMBO               1001
#define IDC_COPY_CHECK                  1002
#define IDC_PROGRESS1                   1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
